/**
 * @file token.cpp
 * @brief Реализация проверок на ключевые слова
 */
#include "stdafx.h"
#include "token.h"


namespace escript {


} // namespace escript
