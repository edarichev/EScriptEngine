#ifndef BOOLEAN_TEST_H
#define BOOLEAN_TEST_H


class Boolean_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_trueFalse();
};

#endif // BOOLEAN_TEST_H
