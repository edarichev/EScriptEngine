/**
 * @file stdafx.cpp
 * @brief Precompiled header
 */
#include "stdafx.h"
