/**
 * @file instruction.h
 * @brief Машинная инструкция (реализация)
 */
#include "stdafx.h"
#include "instruction.h"

namespace escript {

Instruction::Instruction()
{

}

Instruction::~Instruction()
{

}


} // namespace escript
