#ifndef STDAFX_H
#define STDAFX_H

#include <memory>
#include <iostream>
#include "escript.h"
#include "lexer.h"
#include <cassert>
#include <locale>
#include <codecvt>
#include <limits>
#include "compare.h"

using namespace escript;
using namespace std;


#endif // STDAFX_H
