#ifndef DOWHILESTATEMENT_TEST_H
#define DOWHILESTATEMENT_TEST_H


class DoWhileStatement_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_dowhile();
};

#endif // DOWHILESTATEMENT_TEST_H
