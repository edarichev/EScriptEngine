#ifndef FORSTATEMENT_TEST_H
#define FORSTATEMENT_TEST_H


class ForStatement_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_for();
};

#endif // FORSTATEMENT_TEST_H
