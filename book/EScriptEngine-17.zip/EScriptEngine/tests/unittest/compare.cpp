#include "stdafx.h"
#include "compare.h"

