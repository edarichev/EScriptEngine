x = [0, 0.5, 1, 1.5, 2];
console.log("type=" + typeof x + "\nvalue=" + x);

