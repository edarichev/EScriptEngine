x = [0, 1, "hello, world", 7];
console.log("type=" + typeof x + "\nvalue=" + x);

