x = [1];
console.log("type=" + typeof x + "\nvalue=" + x);

