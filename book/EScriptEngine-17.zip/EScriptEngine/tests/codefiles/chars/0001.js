x = "Hello, \u{1F310}";
console.log("type=" + typeof x + "\nvalue=" + x);

