let x = Infinity;
x += 0;
console.log("type=" + typeof x + "\nvalue=" + x);
