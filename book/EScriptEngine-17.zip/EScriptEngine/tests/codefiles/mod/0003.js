x = -5.6;
x %= 2;
console.log("type=" + typeof x + "\nvalue=" + x);

