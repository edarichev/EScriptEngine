x = -5.4;
x %= 2;
console.log("type=" + typeof x + "\nvalue=" + x);

