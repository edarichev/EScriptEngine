let x = null;
x += 0;
console.log("type=" + typeof x + "\nvalue=" + x);
