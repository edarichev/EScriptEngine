i = 9; if (i == 9); else;
console.log("type=" + typeof i + "\nvalue=" + i);

