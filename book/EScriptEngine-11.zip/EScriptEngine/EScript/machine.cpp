/**
 * @file machine.h
 * @brief Исполняющая машина (реализация)
 */
#include "stdafx.h"
#include "machine.h"

namespace escript {

Machine::Machine()
{

}

Machine::~Machine()
{

}


} // namespace escript
