#ifndef CODEGEN_TEST_H
#define CODEGEN_TEST_H


class CodeGen_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_simpleExpression();
};

#endif // CODEGEN_TEST_H
