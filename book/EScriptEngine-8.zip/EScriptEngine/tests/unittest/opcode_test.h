#ifndef OPCODE_TEST_H
#define OPCODE_TEST_H


class OpCode_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_opCodeWork();
};

#endif // OPCODE_TEST_H
