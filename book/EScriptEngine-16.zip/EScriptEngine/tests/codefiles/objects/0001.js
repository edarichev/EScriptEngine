harry = {age:15, name:"harry"};
sally = {age:14, name:"sally"};
harry.friends = [sally]
sally.friends = [harry]
console.log("type=" + typeof harry + "\nvalue=" + harry);

