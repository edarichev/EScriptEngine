let x = true;
x += 0;
console.log("type=" + typeof x + "\nvalue=" + x);
