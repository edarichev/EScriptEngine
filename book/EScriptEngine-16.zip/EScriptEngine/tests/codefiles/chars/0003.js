x = "Hello, \x50";
console.log("type=" + typeof x + "\nvalue=" + x);

