x = "Hello, \u{50}";
console.log("type=" + typeof x + "\nvalue=" + x);

