x = "Hello, \uD83C\uDF10";
console.log("type=" + typeof x + "\nvalue=" + x);

