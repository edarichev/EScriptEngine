x = 56;
x %= 2;
console.log("type=" + typeof x + "\nvalue=" + x);

