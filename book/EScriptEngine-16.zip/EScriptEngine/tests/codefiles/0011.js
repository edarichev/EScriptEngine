let x = "";
x += undefined;
console.log("type=" + typeof x + "\nvalue=" + x);
