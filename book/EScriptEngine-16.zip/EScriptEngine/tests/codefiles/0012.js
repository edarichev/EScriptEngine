let x = "";
x += NaN;
console.log("type=" + typeof x + "\nvalue=" + x);
