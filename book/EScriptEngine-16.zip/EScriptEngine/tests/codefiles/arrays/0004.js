x = [,,1, 2,];
console.log("type=" + typeof x + "\nvalue=" + x);

