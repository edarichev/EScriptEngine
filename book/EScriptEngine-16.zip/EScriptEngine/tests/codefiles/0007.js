let x = undefined;
x += 0;
console.log("type=" + typeof x + "\nvalue=" + x);
