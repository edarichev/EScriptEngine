let x = "";
x += Infinity;
console.log("type=" + typeof x + "\nvalue=" + x);
