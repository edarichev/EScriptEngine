x = []+{};
console.log("type=" + typeof x + "\nvalue=" + x);
