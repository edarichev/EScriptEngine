let x = "";
x += NaN;
console.log(x);
/*
VALUE=x
RESULT=NaN
*/
