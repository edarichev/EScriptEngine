let x = "";
x += null;
console.log("type=" + typeof x + "\nvalue=" + x);
