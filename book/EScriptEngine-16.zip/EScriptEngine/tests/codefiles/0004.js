let x = 0;
x += false;
console.log("type=" + typeof x + "\nvalue=" + x);
