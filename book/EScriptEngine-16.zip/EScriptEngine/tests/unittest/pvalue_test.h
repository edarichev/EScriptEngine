#ifndef PVALUE_TEST_H
#define PVALUE_TEST_H


class PValue_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_operatorLess();
};

#endif // PVALUE_TEST_H
