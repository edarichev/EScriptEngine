#ifndef IFELSESTATEMENT_TEST_H
#define IFELSESTATEMENT_TEST_H


class IfElseStatement_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_ifOnly();
};

#endif // IFELSESTATEMENT_TEST_H
