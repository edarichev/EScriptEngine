#ifndef ASSEMBLER_TEST_H
#define ASSEMBLER_TEST_H


class Assembler_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_byteSequence();
};

#endif // ASSEMBLER_TEST_H
