#ifndef WHILESTATEMENT_TEST_H
#define WHILESTATEMENT_TEST_H


class WhileStatement_Test
{
public:
    void run();
private:
    void initTestCase();
    void cleanupTestCase();
    void test_while();
};

#endif // WHILESTATEMENT_TEST_H
