#ifndef STDAFX_H
#define STDAFX_H

#include <memory>
#include <iostream>
#include "escript.h"
#include "lexer.h"
#include <cassert>
#include <locale>
#include <codecvt>
#include <limits>

#endif // STDAFX_H
