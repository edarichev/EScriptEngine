/**
 * @file lexer.cpp
 * @brief Лексический анализатор - реализация
 */
#include "stdafx.h"
#include "lexer.h"
#include "keyword.h"

namespace escript {

Lexer::Lexer(const std::u32string &strCode)
    : _text(strCode),
      _begin(strCode.begin()),
      _end(strCode.end()),
      _p(strCode.begin())
{

}

Lexer::~Lexer()
{

}

Token Lexer::next()
{
    _tokenText.clear();
    int c = 0;
    while (c >= 0) {
        c = read();
        switch (c) {
        case '=':
            _tokenText.push_back(c);
            return _token = Token::Assign;
        case ';':
            _tokenText.push_back(c);
            return _token = Token::Semicolon;
        case '+':
            _tokenText.push_back(c);
            return _token = Token::Plus;
        default:
            if (isSpace(c))
                continue;
            if (isLetter(c) || c == '_') {
                readIdentifier(c);
                return _token;
            }
            if (c == '.' || isdigit(c)) {
                readNumber(c);
                return _token;
            }
            break;
        }
    }
    return Token::Eof;
}

Token Lexer::currentToken() const
{
    return _token;
}

const std::u32string &Lexer::tokenText() const
{
    return _tokenText;
}

int Lexer::read()
{
    if (_p == _end)
        return -1;
    int c = *_p;
    ++_p;

    if (c == '\n') {
        _prevLineLen = _pos;
        _line++;
        _pos = 1;
    } else {
        if (c != '\r') // не считаем сдвиг на '\r', иначе визуально это будет на
            _pos++;    // 1 символ в строке больше, чем отображается в редакторе
    }
    return c;
}

void Lexer::back()
{
    if (_p == _text.begin())
        throw std::out_of_range("jump over the beginning of the buffer");
    --_p;
    auto c = *_p;
    if (c == '\n') {
        _pos = _prevLineLen;
        _line--;
    } else {
        if (_pos > 0)
            _pos--;
    }
    // обработать \r
    while (*_p == '\r') {
        if (_p == _text.begin())
            break;
        --_p;
    }
}

bool Lexer::isSpace(int charCode) const
{
    switch (charCode) {
    case 0x0020: // пробел, наиболее вероятно
    case 0x0009: // TAB
    case 0x00A0:
    case 0x1680:
    case 0x180E:
    case 0x2000:
    case 0x2001:
    case 0x2002:
    case 0x2003:
    case 0x2004:
    case 0x2005:
    case 0x2006:
    case 0x2007:
    case 0x2008:
    case 0x2009:
    case 0x200A:
    case 0x200B:
    case 0x202F:
    case 0x205F:
    case 0x3000:
    case 0xFEFF:
        return true;
    default:
        break;
    }
    return false;
}

bool Lexer::isLetter(int charCode) const
{
    return std::isalpha(charCode);
}

bool Lexer::isLetterOrDigit(int charCode) const
{
    return isLetter(charCode) || std::isdigit(charCode);
}

void Lexer::readIdentifier(int charCode)
{
    _tokenText.clear();
    while (charCode > 0) {
        _tokenText.push_back(charCode);
        charCode = read();
        if (isLetterOrDigit(charCode) || charCode == '_')
            continue;
        break;
    }
    Token kw = KeyWord::checkKeyWord(_tokenText);
    if (kw == Token::Eof) { // ключевое слово не найдено, это идентификатор
        _token = Token::Identifier;
    } else { // это ключевое слово
        _token = kw;
    }
}

void Lexer::readNumber(int firstChar)
{
    _tokenText.clear();
    bool isReal = firstChar == '.'; // ставили ли уже точку?
    bool hasExpSign = false;        // есть + или -, иначе ошибка
    bool hasExpE = false;           // знак E
    bool hasExpNum = false;         // есть ли число после E
    _tokenText.push_back(firstChar);
    int c;
    while ((c = read()) > 0) {
        if (std::isdigit(c)) {
            if (hasExpE)
                hasExpNum = true;
            _tokenText.push_back(c);
            continue;
        } else if (c == '.') {
            if (_tokenText.length()) {
                if (_tokenText.find_first_of('.') == _tokenText.length() - 1) {
                    // в числе есть последняя точка, но идут две точки подряд -
                    // надо вернуть число, а две точки запихнуть обратно
                    back();
                    back();
                    _tokenText.erase(_tokenText.length() - 1, 1);
                    isReal = hasExpE; // иначе это целое, т.к. точки нет
                    break;
                } else {
                    // эта точка - после разобранного числа
                    if (hasExpE && hasExpNum) { // число закончилось
                        // это какая-то другая точка,
                        // разберём на следующем проходе
                        back();
                        break;
                    } // ниже вылетим в unexpected
                }
            }
            if (isReal) // точка уже есть, неправильное число
                unexpected(c);
            isReal = true;
        } else if (c == '+' || c == '-') {
            if (hasExpSign)
                unexpected(c);
            hasExpSign = true;
        } else if (c == 'E' || c == 'e') {
            if (hasExpE)
                unexpected(c);
            hasExpE = true;
            isReal = true;
        } else {
            back(); // символ не допускается в число
            break;
        }
        _tokenText.push_back(c);
    }
    if (isReal)
        _token = Token::RealNumber;
    else
        _token = Token::IntegerNumber;
}

void Lexer::error(const std::string &msg)
{
    std::cout << "line: " << _line << ", pos:" << _pos << " " << msg;
    exit(1);
}

void Lexer::unexpected(char unexpectedChar)
{
    error(std::string("Unexpected character: [") + unexpectedChar + "]");
}

} // namespace escript
