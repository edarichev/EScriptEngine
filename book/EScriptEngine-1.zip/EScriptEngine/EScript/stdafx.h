/**
 * @file stdafx.h
 * @brief Precompiled header
 */
#ifndef STDAFX_H
#define STDAFX_H

#include <memory>
#include <string>
#include <iostream>
#include <map>
#include <locale>
#include <codecvt>
#include <exception>

#endif // STDAFX_H
