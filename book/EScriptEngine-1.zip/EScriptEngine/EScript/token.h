/**
 * @file token.h
 * @brief Определение токенов
 */
#ifndef TOKEN_H
#define TOKEN_H

namespace escript {

/**
 * @brief Токен/лексема
 */
enum class Token
{
    Eof = 0,            // Конец потока
    Break,              // break
    Case,               // case
    Catch,              // catch
    Class,              // class
    Const,              // const
    Continue,           // continue
    Debugger,           // debugger
    Default,            // default
    Delete,             // delete
    Do,                 // do
    Else,               // else
    Enum,               // enum
    Export,             // export
    Extends,            // extends
    Finally,            // finally
    For,                // for
    Function,           // function
    If,                 // if
    Implements,         // implements
    Import,             // import
    In,                 // in
    Instanceof,         // instanceof
    Interface,          // interface
    Let,                // let
    New,                // new
    Package,            // package
    Private,            // private
    Protected,          // protected
    Public,             // public
    Return,             // return
    Static,             // static
    Super,              // super
    Switch,             // switch
    This,               // this
    Throw,              // throw
    Try,                // try
    Typeof,             // typeof
    Var,                // var
    Void,               // void
    While,              // while
    With,               // with
    Yield,              // yield
    Dot,                // .
    LeftParenth,        // (
    LeftBrace,          // {
    LeftBracket,        // [
    RightParenth,       // )
    RightBrace,         // }
    RightBracket,       // ]
    Plus,               // +
    Minus,              // -
    PlusPlus,           // ++
    MinusMinus,         // --
    Caret,              // ^
    Exclamation,        // !
    Asterisk,           // *
    Slash,              // /
    Percent,            // %
    LShift,             // <<
    RShift,             // >>
    RShiftZero,         // >>>
    Less,               // <
    LessEqual,          // <=
    Greater,            // >
    GreaterEqual,       // >=
    Equal,              // ==
    NotEqual,           // !=
    Identity,           // ===
    NotIdentity,        // !==
    Ampersand,          // &
    Vertical,           // |
    LogicalAnd,         // &&
    LogicalOr,          // ||
    Question,           // ?
    Colon,              // :
    Assign,             // =
    MulAssign,          // *=
    SlashAssign,        // /=
    PlusAssign,         // +=
    MinusAssign,        // -=
    LShiftAssign,       // <<=
    RShiftAssign,       // >>=
    RShiftZeroAssign,   // >>>=
    BitAndAssign,       // &=
    XorAssign,          // ^=
    BitOrAssign,        // |=
    Comma,              // ,
    Semicolon,          // ;
    RealNumber,         // действительное число
    IntegerNumber,      // целое число
    QuotedString,       // строка в кавычках
    Identifier,         // идентификатор
};

} // namespace escript

#endif // TOKEN_H
